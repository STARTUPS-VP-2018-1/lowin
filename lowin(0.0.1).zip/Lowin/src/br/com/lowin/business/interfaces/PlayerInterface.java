package br.com.lowin.business.interfaces;

import br.com.lowin.dominios.Player;
import java.util.List;

public interface PlayerInterface {

    public Player salvarPlayer(Player player);

    public Player buscarPlayerPorUsuario(Integer usuario);

    public List<Player> buscarPlayerPorNome(String nome);

    public List<Player> buscarTodosPlayers();
}
