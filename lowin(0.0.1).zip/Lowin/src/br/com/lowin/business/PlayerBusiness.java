package br.com.lowin.business;

import br.com.lowin.dominios.Player;
import java.util.List;
import br.com.lowin.business.interfaces.PlayerInterface;

public class PlayerBusiness implements PlayerInterface{

    @Override
    public Player salvarPlayer(Player player) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Player buscarPlayerPorUsuario(Integer usuario) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Player> buscarPlayerPorNome(String nome) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Player> buscarTodosPlayers() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
