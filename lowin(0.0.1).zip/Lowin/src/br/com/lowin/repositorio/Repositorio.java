package br.com.lowin.repositorio;

import br.com.lowin.dominios.Player;
import java.util.ArrayList;
import java.util.List;

public class Repositorio {

    public static List<Player> clienteDBFake = new ArrayList<Player>();

}
